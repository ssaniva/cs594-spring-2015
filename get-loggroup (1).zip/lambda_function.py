import json

print('Loading function')


def lambda_handler(event, context):
    cw = boto3.client('logs')
    s3 = boto3.client('s3')

    bucket = 'gaurav1213'
    rfile = 'loggroups_r.txt'
    lfile = 'loggroups_l.txt'

    groups = cw.describe_log_groups()['logGroups']
    grp = []
    for group in groups:
        grp.append(group['logGroupName'])

    #writing contents to file
    file1 = open(lfile, "w+")
    for x in grp:
        file1.write(x + ',')
    file1.close()

    #fetch file from s3
    s3.download_file(bucket, key, rfile)
    tmpfile = open(rfile, "w+")
    pgrp = []
    for f in tmpfile:
        f = f.split('\n')
        pgrp.append(f[0])

    #verifying
    newgroup = []
    for group in grp:
        if group not in pgrp:
            newgroup.append(group)

    #uploading file to s3
    s3.upload_file(lfile, bucket, rfile)

    return newgroup
    print(newgroup)
